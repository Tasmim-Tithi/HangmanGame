package myhangmangame;

/**
 * A simple Hangman application written in Java.
 * @author Tasmim Tithi
 */
public class MyHangmanGame
{
    public static void main(String[] args) 
    {
        GameBoard newHangmanGame = new GameBoard();
    }
}

 